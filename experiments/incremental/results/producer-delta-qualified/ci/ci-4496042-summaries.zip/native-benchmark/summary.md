# Native identity-index whole-process benchmark

**Correctness:** PASS. **Economic result:** NO_SPEEDUP.

Median fresh-process measurements; seconds and KiB. Raw logs and all repetitions are retained in `summary.json` and per-command files.

| Variant | Arm | Wall | CPU | Peak RSS |
| --- | --- | ---: | ---: | ---: |
| baseline | baseline-python-full | 5.737526 | 5.724633 | 287256 |
| baseline | baseline-python-incremental | 0.211926 | 0.200988 | 274108 |
| baseline | native-full | 0.726839 | 0.714070 | 274108 |
| baseline | native-incremental | 0.212055 | 0.203543 | 274108 |
| baseline | baseline-direct-full | 0.334476 | 0.333195 | 274372 |
| baseline | current-direct-full | 0.354859 | 0.346618 | 274108 |
| early-definition | baseline-python-full | 5.781617 | 5.766315 | 283172 |
| early-definition | baseline-python-incremental | 5.532645 | 5.519309 | 294932 |
| early-definition | native-full | 0.727672 | 0.714913 | 274108 |
| early-definition | native-incremental | 0.506086 | 0.495748 | 274108 |
| early-definition | baseline-direct-full | 0.343801 | 0.339527 | 274108 |
| early-definition | current-direct-full | 0.343830 | 0.340227 | 274108 |
| unrelated-definition | baseline-python-full | 5.763604 | 5.751385 | 287236 |
| unrelated-definition | baseline-python-incremental | 5.436023 | 5.421088 | 294944 |
| unrelated-definition | native-full | 0.717785 | 0.707810 | 274108 |
| unrelated-definition | native-incremental | 0.465028 | 0.455693 | 274108 |
| unrelated-definition | baseline-direct-full | 0.333658 | 0.331111 | 274108 |
| unrelated-definition | current-direct-full | 0.343458 | 0.336281 | 274108 |
| theorem-leaf | baseline-python-full | 5.724573 | 5.713477 | 286384 |
| theorem-leaf | baseline-python-incremental | 5.483845 | 5.471238 | 299136 |
| theorem-leaf | native-full | 0.727681 | 0.718566 | 274108 |
| theorem-leaf | native-incremental | 0.456023 | 0.451035 | 274108 |
| theorem-leaf | baseline-direct-full | 0.334289 | 0.331563 | 274108 |
| theorem-leaf | current-direct-full | 0.344099 | 0.338444 | 274108 |
| invalid-proof | baseline-python-full | 5.742486 | 5.731788 | 279312 |
| invalid-proof | baseline-python-incremental | 5.407685 | 5.400000 | 288092 |
| invalid-proof | native-full | 0.669800 | 0.665403 | 274108 |
| invalid-proof | native-incremental | 0.405278 | 0.403868 | 274108 |
| invalid-proof | baseline-direct-full | 0.344556 | 0.337666 | 274108 |
| invalid-proof | current-direct-full | 0.354188 | 0.349007 | 274108 |
| axiom-type | baseline-python-full | 5.355261 | 5.347565 | 279340 |
| axiom-type | baseline-python-incremental | 5.426912 | 5.425162 | 288108 |
| axiom-type | native-full | 0.374302 | 0.370031 | 274108 |
| axiom-type | native-incremental | 0.425433 | 0.423824 | 274108 |
| axiom-type | baseline-direct-full | 0.041009 | 0.037509 | 274108 |
| axiom-type | current-direct-full | 0.040787 | 0.036382 | 274372 |

| Primary variant | Native/direct median ratio | Paired wins | Bootstrap 95% interval | Economic gate |
| --- | ---: | ---: | --- | --- |
| early-definition | 1.4719 | 0/5 | [1.3551, 1.8520] | NO_SPEEDUP |
| unrelated-definition | 1.3540 | 0/5 | [1.3247, 1.4987] | NO_SPEEDUP |

The prespecified rule requires a lower median, a strict majority of paired wins and a paired-bootstrap 95% upper ratio bound below one for both primary edits. The comparison uses current direct raw full checking.

Baseline seeding is separate from timed incremental verification. Build/export resources and component-addition totals are reported separately; those sums are not new single-command measurements. Bootstrap stability on this finite run does not establish cross-host or Mathlib-scale speedup.

`max_rss_kib` is the raw wait4 highwater. It can include memory inherited from this Python launcher before exec, so it does not establish checker-only or aggregate process-tree peak memory or memory savings. The separate `profile_native_phases.py` diagnostic records post-exec RSS samples by phase.

Failed correctness gates: 
