# Incremental external checking qualification

Qualification passed: **True**

| Edit | Full obligations | Rechecked | Reused | Fresh verify s | Incremental verify s | Fresh build+export+verify s | Incremental build+export+verify s |
|---|---:|---:|---:|---:|---:|---:|---:|
| no-change | 3436 | 0 | 3436 | 0.718 | 0.202 | 2.739 | 2.224 |
| early-definition | 3436 | 413 | 3023 | 0.728 | 0.495 | 2.663 | 2.430 |
| unrelated-definition | 3436 | 1 | 3435 | 0.727 | 0.464 | 2.767 | 2.504 |
| theorem-leaf | 3436 | 1 | 3435 | 0.719 | 0.455 | 2.612 | 2.348 |
| type-change | 3436 | 2 | 3434 | 0.729 | 0.465 | 2.621 | 2.358 |
| invalid-proof | 3436 | None | 3435 | 0.668 | 0.405 | boundary mutation | boundary mutation |
| axiom-type | 3436 | None | 0 | 0.364 | 0.425 | boundary mutation | boundary mutation |
| toolchain-metadata | 3436 | 3436 | 0 | 0.718 | 0.778 | boundary mutation | boundary mutation |
| malformed-unused-dag | ? | ? | ? | 5.570 | 5.660 | boundary mutation | boundary mutation |
| malformed-unused-typed-node | 3436 | None | 3436 | 5.485 | 5.583 | boundary mutation | boundary mutation |

Authenticated selected-obligation work reduction and exact-export oracle agreement. Timing medians are observations; edit speedup is not assumed. The bounded Lean theorem does not verify the NDJSON dependency extractor or production kernel locality.

Optional kernel statuses: lean4lean=ACCEPT, con-leche=ACCEPT, con-ron=ACCEPT, nanoda_bin=ACCEPT

Failed gates: 
