# Native identity qualification

Correctness passed: **True**

Index cases: 82; original gates: 197.

| Case | Python index | Native index | Equal or explicit decline | Backend decisions |
|---|---|---|---|---|
| baseline | True | True | True | True |
| early-definition | True | True | True | True |
| unrelated-definition | True | True | True | True |
| theorem-leaf | True | True | True | True |
| type-change | True | True | True | True |
| invalid-proof | True | True | True | True |
| axiom-type | True | True | True | True |
| toolchain-metadata | True | True | True | True |
| malformed-unused-dag | False | False | True | True |
| malformed-unused-typed-node | True | False | True | True |
| simple | True | True | True | True |
| minimal-metadata-python-only | True | False | True | True |
| json-whitespace-reordered | True | True | True | True |
| unicode-3 | True | True | True | True |
| unicode-4 | True | True | True | True |
| unicode-5 | True | True | True | True |
| unicode-6 | True | True | True | True |
| unicode-7 | True | True | True | True |
| unicode-8 | True | False | True | True |
| literal-unicode | True | True | True | True |
| scalar-10 | True | True | True | True |
| scalar-11 | True | True | True | True |
| scalar-12 | True | True | True | True |
| scalar-13 | True | True | True | True |
| scalar-boundary-14 | True | False | True | True |
| scalar-boundary-15 | True | False | True | True |
| scalar-boundary-16 | True | False | True | True |
| scalar-boundary-17 | True | False | True | True |
| scalar-boundary-18 | True | False | True | True |
| metadata-scalar-19 | True | True | True | True |
| metadata-scalar-20 | True | False | True | True |
| metadata-scalar-21 | True | False | True | True |
| metadata-scalar-22 | True | True | True | True |
| metadata-scalar-23 | True | False | True | True |
| metadata-scalar-24 | True | False | True | True |
| binder-default | True | True | True | True |
| binder-implicit | True | True | True | True |
| binder-strictImplicit | True | True | True | True |
| binder-instImplicit | True | True | True | True |
| binder-unknown | True | True | True | True |
| binder-missing | False | False | True | True |
| binder-null | True | True | True | True |
| binder-extra | False | False | True | True |
| let-False | True | True | True | True |
| let-True | True | True | True | True |
| declaration-all | True | True | True | True |
| declaration-hints | True | False | True | True |
| declaration-safety | False | False | True | True |
| quot-kind-0 | True | False | True | True |
| quot-kind-1 | True | False | True | True |
| quot-kind-2 | True | False | True | True |
| quot-kind-3 | True | False | True | True |
| inductive-nested-0-reflexive-False | True | True | True | True |
| inductive-nested-1-reflexive-False | True | True | True | True |
| inductive-nested-2-reflexive-False | True | True | True | True |
| inductive-nested-0-reflexive-True | True | True | True | True |
| block-regrouping-False | True | True | True | True |
| block-regrouping-True | True | True | True | True |
| empty-inductive-block | True | True | True | True |
| scc-diamond-False | True | True | True | True |
| scc-diamond-True | True | True | True | True |
| renumbering-False | True | True | True | True |
| renumbering-True | True | True | True | True |
| builtin-False | True | True | True | True |
| builtin-True | True | True | True | True |
| ambiguous-builtin-display | False | False | True | True |
| forward-dag | False | False | True | True |
| duplicate-dag | False | False | True | True |
| boolean-dag-index | False | False | True | True |
| boolean-dag-reference | False | False | True | True |
| negative-dag-reference | False | False | True | True |
| extra-row-field | False | False | True | True |
| unknown-tag | False | False | True | True |
| repeated-metadata | False | False | True | True |
| duplicate-declaration | False | False | True | True |
| duplicate-key | False | False | True | True |
| duplicate-nested-key | False | False | True | True |
| invalid-json-leading-zero | False | False | True | True |
| invalid-json-control | False | False | True | True |
| json-array-row | False | False | True | True |
| truncated-json | False | False | True | True |
| sparse-indices | True | True | True | True |

Native identity is an optional accelerator. Successful native indexes equal the original Python structure exactly. Native declines use Python identity and still require the existing checker on changed bytes. Backend caches are populated separately; evidence IDs and tool provenance differ. This qualification makes no claim that incremental checking is faster than direct full checking.

Failed gates: 
