# One-shot retained native Rust parser: shadow low-level experiment

This reports parser/kernal phase economics, NOT a new accepted receipt or full producer-to-durable lifecycle speedup.
Baseline parsed once on session startup (charged separately). Each compared changed export uses genuine source-owned Lean data.
Original full Rust selected checker and fresh Rust/C++/paranoid full oracles remain acceptance authorities.

| Workload / edit | Fresh selected checker | Retained parsed-state checker | Median savings | Delta parse+finish |
| --- | ---: | ---: | ---: | ---: |
| original / early-definition | 0.062660s | 0.037021s | 40.92% | 0.000137s |
| original / unrelated-definition | 0.026501s | 0.001729s | 93.48% | 0.000141s |
| expanded / early-definition | 0.127678s | 0.070263s | 44.97% | 0.000503s |
| expanded / unrelated-definition | 0.098618s | 0.043274s | 56.12% | 0.000629s |

Same-kernel parity on accepted real source, genuine typed full-index oracle, protected malformed/overwrite delta parser refusals required.
New retained parser executable semantics are not machine-proven. The producer, attestation and HMAC policy are also outside the kernel proof.
Cold startup, arbitrary Lean declarations/topology and true end-to-end change-proportional checking remain UNKNOWN.
