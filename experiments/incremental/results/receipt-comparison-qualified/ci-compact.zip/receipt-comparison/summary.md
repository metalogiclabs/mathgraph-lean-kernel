# Same-source retained-kernel receipt issuance: shared JSON comparison versus canonical JSON comparison.

Same source-owned producer, HMAC authentication, conservative reuse, full sealed input and signed sparse receipts.
Every arm has independent full Rust/index/partition/receipt audits; first pairs also have full C++ and paranoid checks.
Warm apply excludes initial setup. Cold replay and setup plus one apply components are separate; no update-stream amortization.

| Source / edit | Canonical JSON warm (s) | Shared JSON warm (s) | Saving | Wins | Bootstrap 95% ratio | Gate |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| original / early-definition | 0.164907 | 0.135640 | 17.75% | 5/5 | [0.80384,0.87585] | SPEEDUP |
| original / unrelated-definition | 0.130641 | 0.103014 | 21.15% | 5/5 | [0.59159,0.82835] | SPEEDUP |
| expanded / early-definition | 0.419135 | 0.401830 | 4.13% | 5/5 | [0.53990,0.97695] | SPEEDUP |
| expanded / unrelated-definition | 0.503092 | 0.260504 | 48.22% | 5/5 | [0.50082,0.96439] | SPEEDUP |

CPU, all phase/resource observations, same-input direct Rust comparisons, cold replay and representative full witnesses are preserved in the JSON reports.
NO_SPEEDUP is a valid economic result and does not change the independent correctness qualification.
Frozen bounded tests do not formally prove the retained parser bridge or qualify a multi-update lifetime.
