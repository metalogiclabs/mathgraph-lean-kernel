from pathlib import Path
from argparse import Namespace
import sys,json,hashlib
sys.path.insert(0,'/workspace/mathgraph-lean-kernel-retained-admission/experiments/incremental')
import benchmark_retained_admission as b
out=Path('/workspace/kernel-audit/retained-admission-continuation/pair-smoke-original')
out.mkdir(exist_ok=False)
bins=Path('/workspace/mathgraph-lean-kernel/target/release')
work=Path('/workspace/kernel-audit/workloads-final')
a=Namespace(original_workloads=work,expanded_workloads=Path('/workspace/kernel-audit/delta-expanded-workloads-first'),
 producer=Path('/workspace/kernel-audit/delta-qualified-tools/delta-producer'),checker=bins/'check-selected',
 retained_checker=bins/'check-selected-retained-session',indexer=bins/'export-index',index_session=bins/'index-session',
 full_checker=bins/'sokonanoda',authority_key=Path('/workspace/kernel-audit/retained-admission-continuation-authority/issuer.key'),
 out=out,repetitions=5)
rows={}
for mode in b.RECEIPT_MODES:
 q=b.qualifier(a,work,'original',mode,'diagnostic-one-pair')
 q.preflight();refs={v:q.reference(v) for v in ('baseline','early-definition')}
 s=q.sample('early-definition',0,refs);r,audit=b.verified_result(s,mode)
 arm=b.actual_arm(s,r,audit);w=b.preserve_witness(a,'original','early-definition',mode,s,r)
 rows[mode]=dict(arm=arm,witnesses=w)
 print(mode,arm['wall_seconds'],arm['checked'],flush=True)
assert rows['canonical_json']['arm']['decisions_sha256']==rows['shared_json']['arm']['decisions_sha256']
assert rows['canonical_json']['arm']['export_sha256']==rows['shared_json']['arm']['export_sha256']
report=dict(status='DIAGNOSTIC_PAIR_PASS_NOT_FIVE_PAIR_QUALIFICATION',arms=rows,
 scope='Actual complete admitted-kernel transactions, independent full index/Rust/C++/paranoid and signed receipt audits. One pair cannot qualify economics.')
(out/'diagnostic.json').write_text(json.dumps(report,indent=2)+'\n')
print(report['status'])
