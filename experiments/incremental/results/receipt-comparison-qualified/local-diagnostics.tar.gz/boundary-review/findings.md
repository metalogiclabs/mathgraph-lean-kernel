# Independent read-only boundary review

Reviewed candidate `6e717043b85acdad63c2399131cb5f9a7432ee37` against qualified `f02c02d5c87c2e6e31774a746557829b2d27b6c4` and shadow `fea752338083c63ff7fbd0d18d8295b9f6658db2`. No concrete unsafe acceptance path was found within the declared private, one-shot, source-owned applicability boundary. This is source review and compact-report consistency checking, not a new executable oracle replay or formal equivalence proof.

`audit_readonly.py` was actually executed on the fetched Git objects and downloaded CI38995206988 artifact. It validates archive SHA, all measured source hashes, required gates, reported native/checker and cold-control results, and all five A/B pairs. Output: `reported-ci-audit.json`, SHA256 `8fba2be440076eb2918d80dae11652f64a8a0df3f9fc537fb7f5b33c65e60a1a`.

## What is unchanged, and what is trusted now

`engine.py`, `tc.rs`, `env.rs`, `identity.rs`, `index_session.rs`, and `check_selected.rs` are byte-identical across the three revisions. Candidate parser and retained executable source are byte-identical to the shadow revision. Ordinary `Parser::finish` is unchanged across all three. Exact source hashes are preserved in `source-comparison.json` and the replayable report.

The caller authenticates the original complete baseline and transition under the existing issuer key. The new backend digest is added to purpose-separated producer provenance and genesis; changing it on restart changes the expected genesis. The old reuse function still selects obligations, and signed sparse acceptance is written only after actual native selected-check success and count checks. These statements do not remove the new semantic trust assumption: the retained parser/state bridge is a new explicitly pinned dependency. The old reuse function receives the baseline's original provenance; it does not itself prove equivalence between the original complete parser executable and the new retained backend.

The retained process does not parse the new sealed composite. It independently hashes/parses the original baseline and delta and replaces existing AST declarations. The adapter separately materializes/hashes/seals the complete composite. Their equivalence is established operationally on bounded fixtures by independent fresh indexes and kernels; it is not established merely by signing the backend digest or by unchanged checking code.

## Invalidation and state lifetime

- Baseline bytes are regenerated from pinned source, compared with their pin and authenticated durable bytes at each cold start. A live frozen Python `bytes` object is explicitly the warm authority. A later disk change cannot mutate that historical snapshot; a cold restart reauthenticates storage.
- The native baseline is fully parsed and hash-bound before its ready response. There is no prior semantic inference/evaluation cache to invalidate: baseline parser state contains structural DAG/declaration data, and selected typechecking starts after the delta.
- Delta application consumes the native parser by value; the process permits only one request, exits on parse/check failure, and the Python adapter poisons its session before validation. Process memory is private and is not reconstructed from serialized parser/cache fields.
- Every delta row is parsed before selected checking, including unused rows with an empty selection. Baseline DAG slots cannot be overwritten. The index process independently rejects duplicate DAG indices and validates typed references before the kernel request.
- Same-kind def/thm/opaque replacement uses `get_mut` at the original typed name, preserving the ordered map slot and the name's old declaration index. The original mutual-block map and prefix-visibility checking remain in use. No declaration insertion is allowed.
- Changed dependency topology/new name entries cause the existing indexer to fall back to full identity finish. This is an identity fallback, not a promise of native support for every export transition. Metadata, quotient, inductive, axiom replacement, kind changes, new declarations, and schedule changes are refused by the materializer and/or retained parser. No implicit full-parser acceptance fallback is present.
- Original global/builtin/complex/schedule assumptions are still evaluated by the unchanged reuse predicate. Complex declarations after a changed verified prefix are selected conservatively. `Parser::finish` regenerates the name cache after the delta, rather than retaining a stale semantic builtin lookup table.

This model relies on trusted private controller/process state and source-owned immutable imported context. An unauthenticated caller may supply arbitrary baseline hash and selected list to the low-level native executable; its response deliberately is not an issuer acceptance certificate. Neither arbitrary mutable filesystem unchangedness nor corrupted host memory is claimed to be established by this protocol.

## What CI actually exercised

The compact artifact binds to clean candidate source and reports246 original /229 expanded required gates, all passed, with21 positive/cold samples per profile. It reports expected seven cold-storage corruption refusals and foreign-issuer refusal in both profiles. All measured source hashes independently match the candidate Git blobs.

The signed invalid-proof controls reach actual selected checking and fail there. The signed invalid-axiom controls are refused earlier because axioms are outside simple replacement policy; they do not demonstrate retained axiom semantic-check parity. Both unused-node delta forms per profile reach the retained parser with scheduled=0 and fail on the malformed noninteger u16. Full fresh Rust/C++/paranoid rejection and fresh zero-selected parser refusal are separately recorded by the CI harness.

The compact admission archive contains reports, not the per-sample result files, native stdout/stderr streams, full exports, or issuer keys. Some A/B data and native reports are embedded directly; protected positive backend execution is otherwise evidenced by source and harness-produced audits. This review rechecks those observations, not remote process execution independently. Low-level shadow malformed/overwrite controls belong to the prior shadow qualification; the admission workflow does not rerun that entire standalone shadow matrix. Arbitrary name spellings/topology, a general decoder bridge, multi-update retention, and cold lifetime economics remain outside qualification.

## Economic boundary and smallest remaining cost

The protected producer-to-raw-full-Rust comparison passes its warm speedup gate in both profiles. The stricter candidate fresh-selected versus retained-selected A/B comparison has these distinct outcomes:

| Profile / edit | Fresh warm median | Retained warm median | Retained persistence median | A/B gate |
| --- | ---: | ---: | ---: | --- |
| Original / early |0.178698s|0.158873s|0.040156s|NO_SPEEDUP|
| Original / unrelated |0.134423s|0.115955s|0.040910s|SPEEDUP|
| Expanded / early |0.666310s|0.526918s|0.162366s|NO_SPEEDUP|
| Expanded / unrelated |0.503202s|0.535416s|0.170015s|NO_SPEEDUP|

The other three A/B bootstrap95% upper ratio bounds exceed one. The `qualified=true` comparison report is completion/correctness, not evidence that all four economics gates passed. One baseline-anchored edit is measured after fresh setup; median setup is roughly4.2s original and15.3–15.6s expanded, separately excluded. No cold or total-lifetime win follows.

The smallest concrete remaining hot region is the sparse receipt persistence self-audit in `producer_delta.py` around lines714–723: sign a small receipt, authenticate it again, reconstruct its complete index, rerun full reuse decisions, then canonical-JSON-encode both reconstructed and live complete indexes solely for comparison. The durable receipt is sparse but this work is still proportional to all declarations. Its measured persistence phase is larger than retained kernel checking on these pairs. Determining the exact removable share requires local profiling; this review does not claim that all persistence time is serialization or recommend dropping authentication/cold checks.

Other full-size costs remain:16/64MB complete materialization+SHA for the sealed oracle/representation; whole-list reuse decisions and result construction; and native `finish` rebuilding its name cache. The compact artifact does not isolate their individual wall times. No new engine is needed to investigate the redundant full-index encoding; any change still needs exact typed equality and untrusted cold-validation behavior preserved.

## Remaining qualification work

Before claiming a stronger acceptance model, independently replay actual native transitions and direct low-level refusal controls against preserved full-parser oracles, including direct metadata/axiom/inductive/new-name/duplicate-appended-index requests, malformed unused nodes under zero selection, and killed/second-attempt sessions. These are qualification gaps, not observed acceptance bugs. Before claiming stronger economics, profile the existing receipt self-audit and full materialization under the same complete timed apply boundary, then rerun paired comparisons and preserve negative economic outcomes.
