#!/usr/bin/env python3
"""Read Git objects and compact reports; no checker, producer or cache execution."""
import argparse,hashlib,json,statistics,subprocess,zipfile
from pathlib import Path
CANDIDATE='6e717043b85acdad63c2399131cb5f9a7432ee37'
QUALIFIED='f02c02d5c87c2e6e31774a746557829b2d27b6c4'
SHADOW='fea752338083c63ff7fbd0d18d8295b9f6658db2'
EXPECTED_ZIP='0532de6895cf6c573fe81213cc6f62749aa8049d2b1640686cc57fcd9c9310cb'
def sha(raw):return hashlib.sha256(raw).hexdigest()
def require(value,why):
 if not value:raise ValueError(why)
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--repo',type=Path,required=True);p.add_argument('--zip',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args()
 def blob(ref,name):return subprocess.check_output(['git','show',ref+':'+name],cwd=a.repo)
 sources={}
 for name in ['experiments/incremental/engine.py','src/tc.rs','src/env.rs','src/parser.rs','src/identity.rs','src/bin/index_session.rs','src/bin/check_selected.rs']:
  sources[name]={ref:sha(blob(ref,name))for ref in [QUALIFIED,SHADOW,CANDIDATE]}
  if name!='src/parser.rs':require(len(set(sources[name].values()))==1,'unexpected core change: '+name)
 require(sources['src/parser.rs'][SHADOW]==sources['src/parser.rs'][CANDIDATE],'shadow parser changed')
 native='src/bin/check_selected_retained_session.rs'
 require(blob(SHADOW,native)==blob(CANDIDATE,native),'shadow executable source changed')
 finish={}
 for ref in [QUALIFIED,SHADOW,CANDIDATE]:
  text=blob(ref,'src/parser.rs');start=text.index(b'    fn finish(self)');end=text.index(b'    fn fast_line(',start);finish[ref]=sha(text[start:end])
 require(len(set(finish.values()))==1,'normal parser finish changed')
 raw=a.zip.read_bytes();require(sha(raw)==EXPECTED_ZIP,'unexpected CI archive')
 z=zipfile.ZipFile(a.zip);report={};members={};economics={}
 for profile,min_gates in [('original',246),('expanded',229)]:
  name=f'retained-admission-protected/{profile}/protected-matrix/retained_selected/summary.json';data=z.read(name);q=json.loads(data)
  require(q['source_git_commit']==CANDIDATE and q['source_git_status']=='','protected source mismatch')
  require(q['run_completed']and q['correctness_passed']and q['qualification_status']=='PASS','protected report declined')
  required=[g for g in q['gates']if g['required']];require(len(required)>=min_gates and all(g['passed']is True for g in required),'protected gates incomplete')
  for path,digest in q['measured_source_sha256'].items():require(sha(blob(CANDIDATE,path))==digest,'CI measured source mismatch: '+path)
  controls={}
  for key,c in q['controls'].items():
   result=c.get('result',{});reason=result.get('reason')or result.get('checker_result',{}).get('stderr')or c.get('observed_refusal')or c.get('error')
   controls[key]=dict(status=result.get('status'),reason=reason,scheduled=(result.get('counts')or{}).get('scheduled'),evidence_id=result.get('evidence_id'))
   require(not result.get('evidence_id'),'negative control has acceptance')
   if key.startswith('signed-invalid-')or key.startswith('unused-invalid-'):
    require(result['status']=='REJECTED'and result['checker_result']['code']==1,'signed invalid accepted')
    for command in c['independent_kernel_rejections'].values():require(command['returncode']==1 and not command['timed_out'],'full oracle disagreement')
   if key.startswith('unused-invalid-'):
    require(result['counts']['scheduled']==0 and 'not-an-integer'in result['checker_result']['stderr'],'unused parser not exercised')
    require(c['independent_zero_selected_parser']['returncode']==1 and not c['independent_zero_selected_parser']['timed_out'],'zero parser disagreement')
  require('selected declaration checker thread panicked'in controls['signed-invalid-proof']['reason'],'invalid proof not checked')
  require('unrecognized or repeated simple declaration replacement'in controls['signed-invalid-axiom']['reason'],'axiom refusal scope changed')
  for key in ['baseline-receipt','baseline-export','genesis','accepted-delta-receipt','persisted-delta-bytes','persisted-transition','persisted-representation']:
   require(q['controls']['corrupt-'+key].get('observed_refusal'),'missing actual cold refusal')
  report[profile]=dict(required_gates=len(required),samples=len(q['samples']),controls=controls,measured_sources=q['measured_source_sha256'])
  members[name]=dict(bytes=len(data),sha256=sha(data))
 name='retained-admission-ab/summary.json';data=z.read(name);ab=json.loads(data);members[name]=dict(bytes=len(data),sha256=sha(data))
 require(ab['source_sha']==CANDIDATE and ab['qualified']and ab['completed'],'AB incomplete')
 for path,digest in ab['source_sha256'].items():require(sha(blob(CANDIDATE,path))==digest,'AB source mismatch')
 for profile in ['original','expanded']:
  economics[profile]={}
  require(ab['profiles'][profile]['cold_restart']['passed'],'AB restart declined')
  for variant in ['early-definition','unrelated-definition']:
   row=ab['profiles'][profile][variant];require(row['complete']and len(row['pairs'])==5,'missing pairs')
   modes={}
   for mode in ['fresh_selected','retained_selected']:
    arms=[pair['arms'][mode]for pair in row['pairs']]
    modes[mode]={key:statistics.median(x[key]for x in arms)for key in ['wall_seconds','kernel_seconds','identity_seconds','producer_seconds','persistence_seconds','setup_seconds']}
   for pair in row['pairs']:
    fresh=pair['arms']['fresh_selected'];retained=pair['arms']['retained_selected']
    for key in ['checked','reused','export_sha256','decisions_sha256']:require(fresh[key]==retained[key],'AB semantics differ')
    require(retained['kernel_report']['kernel']=='sokonanoda_real_selected_declaration_check'and retained['kernel_report']['checked']==retained['checked'],'retained selected kernel not recorded')
   economics[profile][variant]=dict(warm_gate=row['warm_economics']['status'],bootstrap95=row['warm_economics']['bootstrap_ratio_interval_95'],medians=modes)
 result=dict(status='PASS_READONLY_SOURCE_AND_REPORTED_CI_CONSISTENCY',candidate=CANDIDATE,qualified=QUALIFIED,shadow=SHADOW,ci_zip_sha256=sha(raw),members=members,source_hashes=sources,normal_parser_finish_sha256=finish,protected_reports=report,economics=economics,helper_sha256=sha(Path(__file__).read_bytes()),scope=['Read-only source review and verification of compact reported observations; no new runtime replay or performance measurement.','New retained decoder/state bridge is an additional explicitly HMAC-pinned trusted dependency; original selected checker and reuse predicate bytes are unchanged.','Protected axiom mutation is policy refusal, not retained axiom semantic-check parity.','Only original/unrelated AB gate is SPEEDUP; remaining three AB gates are NO_SPEEDUP.','Candidate compact archive omits per-sample result.json and raw native streams; source and reported counts do not constitute independent process attestation.'])
 a.out.parent.mkdir(parents=True,exist_ok=True);a.out.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n');print(json.dumps(dict(status=result['status'],sha256=sha(a.out.read_bytes()))))
if __name__=='__main__':main()
