#!/usr/bin/env python3
"""Diagnostic pure-helper costs on exact CI-reference indices; no receipt issuance."""
import fcntl
import hashlib
import json
import os
from pathlib import Path
import random
import statistics
import sys
import time
import zipfile

SOURCE = Path('/workspace/mathgraph-lean-kernel-retained-admission')
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(SOURCE / 'experiments/incremental'))
import engine
import producer_delta as producer

archive = zipfile.ZipFile(OUT / 'retained-kernel-admission-6e71704.zip')
ab = json.loads(archive.read('retained-admission-ab/summary.json'))
report = dict(scope='Diagnostic current unmodified pure operations, no kernel execution or receipt issuance; timings do not qualify adapter economics.',
    source_sha='6e717043b85acdad63c2399131cb5f9a7432ee37',
    sources={p:hashlib.sha256((SOURCE/p).read_bytes()).hexdigest() for p in
        ('experiments/incremental/producer_delta.py','experiments/incremental/engine.py')},
    repetitions=5, cases={}, archive_warm_cpu_memory='NOT PRESENT: CI archive omits result.json and phase CPU/memory; these local self-process diagnostics cannot substitute for live adapter/daemon measurements.')


def observe_memory():
    return {line.split(':',1)[0]:int(line.split()[1]) for line in Path('/proc/self/status').read_text().splitlines()
        if line.split(':',1)[0] in ('VmRSS','VmHWM')}


for profile, evidence, workloads in (
    ('original','delta-small-qualified-v1','workloads-final'),
    ('expanded','delta-expanded-qualified-v2','delta-expanded-workloads-first')):
    summary=json.loads(archive.read(f'retained-admission-protected/{profile}/protected-matrix/retained_selected/summary.json'))
    indices={}
    for variant in ('baseline','early-definition','unrelated-definition'):
        path=Path('/workspace/kernel-audit')/evidence/'references'/variant/'native/index.json'
        indices[variant]=json.loads(path.read_bytes())
        assert hashlib.sha256(engine.encoded(indices[variant])).hexdigest()==summary['references'][variant]['typed_index_sha256']
    baseline_path=Path('/workspace/kernel-audit')/workloads/'baseline/export.ndjson'
    baseline_bytes=baseline_path.read_bytes()
    assert hashlib.sha256(baseline_bytes).hexdigest()==summary['references']['baseline']['export_sha256']
    tick=time.perf_counter();layout=producer.DeltaSession._layout(baseline_bytes)
    layout_seconds=time.perf_counter()-tick
    for variant in ('early-definition','unrelated-definition'):
        baseline,current=indices['baseline'],indices[variant]
        patch=dict(schema='mathgraph.export-identity-baseline-patch.v1',count=baseline['count'],
            declarations=[d for old,d in zip(baseline['declarations'],current['declarations']) if old!=d],
            builtins={k:v for k,v in current['builtins'].items() if baseline['builtins'][k]!=v})
        first=producer.reconstruct_index_patch(baseline,patch)
        second=producer.reconstruct_index_patch(baseline,patch)
        assert engine.encoded(first)==engine.encoded(current)==engine.encoded(second)
        old=dict(index=baseline,provenance={})
        selected,decisions=engine.reuse_decisions(old,first,{},'0'*64)
        expected=ab['profiles'][profile][variant]['pairs'][0]['arms']['retained_selected']
        assert len(selected)==expected['checked']
        delta_path=Path('/workspace/kernel-audit/retained-index/harness-final-smoke-2/samples')/profile/(variant+'-0')/'retained/delta.ndjson'
        delta=delta_path.read_bytes()
        shell=object.__new__(producer.DeltaSession);shell.layout=layout;shell.fd=None
        changed_names=['IncrementalWorkload.early' if variant=='early-definition' else 'IncrementalWorkload.unrelated']

        def replay_discarded_decisions():
            selection,_decisions=engine.reuse_decisions(old,second,{},'0'*64)
            return len(selection)
        calls={
            'reconstruct_index_patch':lambda:producer.reconstruct_index_patch(baseline,patch),
            'reuse_decisions_keep_output':lambda:engine.reuse_decisions(old,first,{},'0'*64),
            'authentication_replay_reuse_drop_decisions':replay_discarded_decisions,
            'two_full_index_canonical_encodes_and_compare':lambda:engine.encoded(second)==engine.encoded(first),
            'materialize_hash_and_seal_exact_composite':lambda:shell._materialize(baseline_bytes,delta,changed_names),
        }
        measurements={name:[] for name in calls}
        for repetition in range(5):
            order=list(calls);random.Random(20261021+repetition).shuffle(order)
            for name in order:
                cpu=time.process_time();wall=time.perf_counter()
                value=calls[name]()
                elapsed=time.perf_counter()-wall;used=time.process_time()-cpu
                if name=='materialize_hash_and_seal_exact_composite':
                    digest,byte_count=value
                    assert digest==expected['export_sha256']
                    assert os.fstat(shell.fd).st_size==byte_count
                    assert fcntl.fcntl(shell.fd,getattr(fcntl,'F_GET_SEALS',1034))&15==15
                    os.close(shell.fd);shell.fd=None
                if name=='two_full_index_canonical_encodes_and_compare':assert value is True
                measurements[name].append(dict(wall_seconds=elapsed,self_cpu_seconds=used,
                    postphase_self_memory_KiB=observe_memory()))
                del value
        report['cases'][profile+':'+variant]=dict(declarations=baseline['count'],affected_patch_rows=len(patch['declarations']),
            full_index_canonical_bytes=len(engine.encoded(current)),baseline_export_bytes=len(baseline_bytes),
            baseline_layout_dag_runs=len(layout['dags']),baseline_layout_declarations=len(layout['declarations']),
            baseline_name_entries=len(layout['names']),cold_layout_seconds=layout_seconds,
            genuine_delta_bytes=len(delta),genuine_delta_sha256=hashlib.sha256(delta).hexdigest(),
            exact_composite_sha256=expected['export_sha256'],selected=len(selected),reused=baseline['count']-len(selected),
            medians={name:{field:statistics.median(row[field] for row in rows) for field in ('wall_seconds','self_cpu_seconds')}
                     for name,rows in measurements.items()},samples=measurements,
            memory_scope='Single profiler process, postphase RSS and cumulative VmHWM include cold fixture/index/layout admission and prior measurements; not production adapter/kernel RSS or a phase peak.')
        print(json.dumps(dict(case=profile+':'+variant,medians=report['cases'][profile+':'+variant]['medians'])),flush=True)
for p,h in report['sources'].items():assert hashlib.sha256((SOURCE/p).read_bytes()).hexdigest()==h
report['status']='PASS_DIAGNOSTIC_EXACT_INPUT_BINDINGS'
(OUT/'existing-operation-profile.json').write_text(json.dumps(report,indent=2)+'\n')
