#!/usr/bin/env python3
"""Deterministic diagnostic snapshot; never issuer keys or raw export/session data."""
from collections import Counter
import gzip, hashlib, io, json, re, tarfile, zipfile
from pathlib import Path
BASE=Path(__file__).resolve().parent
OLD='6e717043b85acdad63c2399131cb5f9a7432ee37'
TARGET='5dfe38b01ca7b1c67f70be4ffb2479978049239e'
ZIP='retained-kernel-admission-6e71704.zip'
ZIP_SHA='0532de6895cf6c573fe81213cc6f62749aa8049d2b1640686cc57fcd9c9310cb'
SECRET=re.compile(rb'gh[pousr]_[A-Za-z0-9_]{20,}|github_pat_[A-Za-z0-9_]{20,}|-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----|Bearer [A-Za-z0-9_.-]{30,}')
def enc(v):return (json.dumps(v,indent=2,sort_keys=True)+'\n').encode()
def sha(b):return hashlib.sha256(b).hexdigest()
def forbidden(p):
 return (any(x in {'session','baseline-cache','__pycache__','.git','authority','deltas'} for x in p.parts)
  or p.suffix in {'.key','.ndjson','.pstats','.pyc','.gz'}
  or p.name in {'issuer.key','authority.key','key.bin','result.json','baseline-result.json','index.json'}
  or p.name.endswith('-result.json'))
def choose():
 selected={}
 def add(p,category):
  r=p.relative_to(BASE)
  if forbidden(r) or not p.is_file() or p.is_symlink():return
  if p.stat().st_size>1000000 and str(r)!=ZIP:return
  selected[r.as_posix()]=category
 for p in BASE.iterdir():
  if not p.is_file() or p.name.startswith('local-diagnostics') or p.name.endswith('-tool-response.json'):continue
  if p.suffix in {'.json','.log','.py'} or p.name==ZIP:
   add(p,'old-provider-metadata' if p.name in {'run.json','jobs.json','artifacts.json','commit.json',ZIP} else 'local-diagnostic-log-or-helper')
 for group in ['source','boundary-review','independent-audit','independent-equality-review','receipt-comparison-review']:
  for p in (BASE/group).rglob('*'):
   if any(x in {'artifact','diagnostic-content','__pycache__'} for x in p.relative_to(BASE).parts):continue
   add(p,group)
 for group in ['profile-expanded-early','profile-expanded-early-after']:
  for p in (BASE/group).iterdir():add(p,'instrumented-local-profile')
 for p in (BASE/'independent-kernels-5dfe').rglob('*'):add(p,'independent-local-fresh-kernel-verdicts')
 for p in (BASE/'ci-39581949051').glob('*.json'):add(p,'current-ci-provider-snapshot')
 for p in (BASE/'pair-smoke-original').rglob('*'):
  r=p.relative_to(BASE)
  if 'baseline' in r.parts or 'references' in r.parts:continue
  if p.name in {'diagnostic.json','packaging-validation.json'}:
   add(p,'dirty-source-one-pair-diagnostic');continue
  if 'final-witness-packaging' in r.parts:
   if p.suffix in {'.json','.log'}:add(p,'final-witness-packaging-metadata')
   continue
  if 'witnesses' in r.parts:continue
  if p.name=='summary.json' or p.suffix in {'.json','.stdout','.stderr'}:add(p,'dirty-source-one-pair-process-metadata')
 return dict(sorted(selected.items()))
def make_tar(payload):
 out=io.BytesIO()
 with gzip.GzipFile(filename='',mode='wb',fileobj=out,compresslevel=9,mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w|',format=tarfile.PAX_FORMAT) as tar:
   for name,data in sorted(payload.items()):
    item=tarfile.TarInfo(name);item.size=len(data);item.mode=0o644;item.mtime=item.uid=item.gid=0;item.uname=item.gname=''
    tar.addfile(item,io.BytesIO(data))
 return out.getvalue()
def main():
 selected=choose();payload={n:(BASE/n).read_bytes() for n in selected};original_hashes={n:sha(b) for n,b in payload.items()}
 assert sha(payload[ZIP])==ZIP_SHA
 with zipfile.ZipFile(io.BytesIO(payload[ZIP])) as z:
  assert z.testzip() is None
  old_entries=[]
  for i in z.infolist():
   assert not forbidden(Path(i.filename)),i.filename
   b=z.read(i);assert not SECRET.search(b),'credential-shaped nested bytes'
   old_entries.append({'name':i.filename,'bytes':len(b),'sha256':sha(b),'crc32':f'{i.CRC:08x}'})
  old_ab=json.loads(z.read('retained-admission-ab/summary.json'))
 economics={profile:{case:v['warm_economics'] for case,v in cases.items() if 'warm_economics' in v} for profile,cases in old_ab['profiles'].items()}
 assert all(economics[p]['early-definition']['status']=='NO_SPEEDUP' for p in ['original','expanded'])
 for n,b in payload.items():
  assert not forbidden(Path(n)),n
  assert not SECRET.search(b),'credential-shaped bytes in '+n
 after=json.loads(payload['profile-expanded-early-after/summary.json'])
 smoke={m:json.loads(payload[f'pair-smoke-original/original/diagnostic-one-pair/{m}/summary.json']) for m in ['canonical_json','shared_json']}
 provenance={'schema':'mathgraph.local-diagnostics-provenance.v1','qualification_claim':False,'speedup_claim':False,
  'target_source':TARGET,'target_workflow_run':39581949051,
  'old_exact_artifact':{'source':OLD,'run':38995206988,'artifact_id':12087424228,'sha256':ZIP_SHA,'bytes':len(payload[ZIP]),'entries':old_entries,'original_warm_economics_unchanged':economics},
  'local_profile_after':{'reported_git_head':after['source_git_head'],'reported_dirty_status':after['source_status'],'adapter_sha256':after['adapter_sha256'],'scope':after['scope']},
  'local_one_pair_smoke':{m:{'reported_git_head':r['source_git_commit'],'reported_dirty_status':r['source_git_status'],'run_completed':r['run_completed'],'recorded_samples':len(r['samples']),'header_repetitions_not_completed_evidence':r['repetitions'],'measured_source_sha256':r['measured_source_sha256']} for m,r in smoke.items()},
  'independent_5dfe_kernel_replay':{'source':TARGET,'status':json.loads(payload['independent-kernels-5dfe/summary.json'])['status'],'scope':'Local kernel/protocol correctness diagnostics; no performance qualification.'},
  'limitations':['Local profiles and one-pair smoke are diagnostics, including their recorded dirty source state.',
   'Smoke headers say repetitions=5, but only one sample is recorded and run_completed=false.',
   'Provider polling metadata is a snapshot; no pending run outcome or future CI artifact is asserted.',
   'Issuer keys, raw NDJSON, sessions, full-index/result duplicates and baseline content are omitted.',
   'Historical SHA256SUMS and witness manifests may refer to omitted blobs; the new package manifest defines included bytes.',
   'This preserves diagnostic records/review helpers, not a complete raw-input/kernel replay environment.']}
 payload['DIAGNOSTIC-PROVENANCE.json']=enc(provenance)
 readme='''# Local continuation diagnostics — no performance qualification

Target source: `5dfe38b01ca7b1c67f70be4ffb2479978049239e`; target workflow run: `39581949051`.
This is a self-contained collection of diagnostic records/review helpers, not a five-pair
qualification, complete raw-input replay bundle, or claim about a pending CI result.

The exact downloaded old `6e717043b85acdad63c2399131cb5f9a7432ee37` artifact is unchanged:
`retained-kernel-admission-6e71704.zip`, 2,761,169 bytes, SHA-256
`0532de6895cf6c573fe81213cc6f62749aa8049d2b1640686cc57fcd9c9310cb`.
Its primary early-edit warm gates remain **NO_SPEEDUP in both profiles**. All original
per-case classifications remain verbatim, including the original unrelated-case result.
No local diagnostic changes or promotes the historical classifications.

Contents: normalized old provider metadata/job logs, independent artifact/boundary/equality
reviews, frozen old source snapshots, local red/green logs, operation-profile summaries and
profiler text, small raw kernel verdict/command records, one-pair cross-mode smoke metadata,
and final witness packaging validation/manifests/compact receipts. The local 5dfe kernel
replay is correctness evidence only, not a performance claim.

DIAGNOSTIC-PROVENANCE.json retains actual reported source hashes and dirty status. The
after-profile and one-pair smoke ran with Git HEAD 6e71704 plus dirty changes. They must not
be relabelled clean 5dfe CI measurements. The smoke headers say repetitions=5, but only one
sample is recorded and run_completed=false; the explicit one-pair status governs. Earlier
source/operation profiles preserve their own reported 6e source and remain diagnostic.

Excluded: issuer/authority key files, credentials, sessions/cache trees, raw NDJSON, pstats,
full indexes/results and duplicate baseline gzip/content. The downloaded ZIP is preserved
once, without its extracted duplicate tree. Historical witness manifests/SHA256SUMS can
refer to deliberately omitted data. Packaging validation records describe the original
local check and do not imply every referenced blob is inside this archive.

local-diagnostics-files.txt lists every member. local-diagnostics-manifest.json records
length/hash/original path/category for data members, excluding itself and SHA256SUMS to
avoid self-reference. SHA256SUMS additionally covers the manifest. Gzip/tar timestamps,
owners and modes are normalized; two in-memory archive builds are byte-identical.
No Git, runtime source, or ROS state was modified by packaging.
'''
 payload['README.md']=readme.encode()
 names=sorted(list(payload)+['local-diagnostics-files.txt','local-diagnostics-manifest.json','SHA256SUMS'])
 payload['local-diagnostics-files.txt']=('\n'.join(names)+'\n').encode()
 records=[{'path':n,'bytes':len(b),'sha256':sha(b),'source_path':n if n in selected else None,'category':selected.get(n,'generated-package-documentation')} for n,b in sorted(payload.items())]
 manifest={'schema':'mathgraph.local-diagnostics-package.v1','target_source':TARGET,'target_workflow_run':39581949051,
  'classification':'LOCAL_DIAGNOSTICS_NOT_QUALIFIED_SPEEDUP','old_primary_early_edit_classification':'NO_SPEEDUP_BOTH_PROFILES_UNCHANGED',
  'archive_member_count':len(names),'data_members':records,'category_counts':dict(sorted(Counter(r['category'] for r in records).items())),
  'exclusions':provenance['limitations'],'metadata_policy':{'tar_mtime':0,'gzip_mtime':0,'uid':0,'gid':0,'mode':'0644','sorted_members':True}}
 payload['local-diagnostics-manifest.json']=enc(manifest)
 payload['SHA256SUMS']=''.join(f'{sha(b)}  {n}\n' for n,b in sorted(payload.items())).encode()
 archive=make_tar(payload);assert archive==make_tar(payload),'deterministic rebuild mismatch';assert len(archive)<10000000
 with tarfile.open(fileobj=io.BytesIO(archive),mode='r:gz') as tar:
  assert tar.getnames()==names
  for i in tar.getmembers():
   assert i.isfile() and not i.issym() and not i.islnk()
   assert i.uid==i.gid==i.mtime==0 and i.mode==0o644
   assert tar.extractfile(i).read()==payload[i.name]
 assert all(sha((BASE/n).read_bytes())==digest for n,digest in original_hashes.items()),'input changed while packaging'
 (BASE/'local-diagnostics.tar.gz').write_bytes(archive)
 for name,internal in [('local-diagnostics-manifest.json','local-diagnostics-manifest.json'),('local-diagnostics-files.txt','local-diagnostics-files.txt'),('local-diagnostics-README.md','README.md')]:
  (BASE/name).write_bytes(payload[internal])
 (BASE/'local-diagnostics.sha256').write_text(f'{sha(archive)}  local-diagnostics.tar.gz\n')
 validation={'status':'PASS_DIAGNOSTIC_PACKAGING_ONLY','archive_bytes':len(archive),'archive_sha256':sha(archive),'archive_members':len(names),'selected_input_files':len(selected),
  'uncompressed_member_bytes':sum(map(len,payload.values())),'deterministic_rebuild_equal':True,'all_member_bytes_and_hashes_verified':True,
  'all_inputs_stable_during_packaging':True,'old_zip_exact_sha_and_all_crcs_verified':True,'credential_pattern_scan_passed':True,
  'authority_key_files_included':False,'raw_ndjson_included':False,'duplicate_full_indexes_included':False,'qualification_claim':False,'speedup_claim':False}
 (BASE/'local-diagnostics-validation.json').write_bytes(enc(validation));print(json.dumps(validation,sort_keys=True))
if __name__=='__main__':main()
