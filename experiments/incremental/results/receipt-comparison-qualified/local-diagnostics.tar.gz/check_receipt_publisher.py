"""Synthetic publisher refusal tests only; never kernel/economic evidence."""
import ast,json,os,subprocess,tempfile,yaml
from pathlib import Path
repo=Path('/workspace/mathgraph-lean-kernel-retained-admission')
workflow=repo/'.github/workflows/incremental-receipt-comparison.yml'
steps=yaml.safe_load(workflow.read_text())['jobs']['qualification']['steps']
step=next(s for s in steps if s.get('name')=='Publish only complete exact-source correctness and contextual economics')
code=step['run'].split("python3 - <<'PY'\n",1)[1].split('\nPY',1)[0]
sha='synthetic-publisher-test-not-a-qualified-source'
os.environ['GITHUB_SHA']=sha
results={}
with tempfile.TemporaryDirectory(prefix='receipt-publisher-falsifiers-') as temporary:
    root=Path(temporary)/'artifacts';root.mkdir()
    proc=subprocess.run(['python3','-c',code],cwd=temporary,env=os.environ,capture_output=True,text=True)
    observation=json.loads((root/'ci-observations.json').read_bytes())
    assert proc.returncode!=0 and not observation['correctness_passed'] and len(observation['failures'])==8
    results['all_reports_missing']={'rejected':True,'failures':observation['failures']}
    tree=ast.parse(code)
    safe=ast.Module(body=[n for n in tree.body if isinstance(n,(ast.Import,ast.ImportFrom,ast.FunctionDef,ast.Assign)) and not (isinstance(n,ast.Assign) and any(isinstance(t,ast.Subscript) for t in n.targets))],type_ignores=[])
    namespace={};exec(compile(safe,'publisher-functions','exec'),namespace)
    namespace.update(root=root,sha=sha)
    def write(p,value):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(value))
    def rejected(name,fn,expected):
        try:fn()
        except (ValueError,KeyError,FileNotFoundError) as error:
            assert expected in str(error),(name,str(error));results[name]={'rejected':True,'cause':str(error)}
        else:raise AssertionError('publisher accepted '+name)
    protected=root/'receipt-protected/protected-summary.json'
    p=lambda n:dict(qualification_status='PASS',required_gates=n,failed_gates=[],source_sha=sha,signed_kernel_backend='sha-pinned-retained-parser-v1')
    report=dict(qualified=True,source_sha=sha,profiles={'original':p(246),'expanded':p(229)})
    write(protected,{**report,'source_sha':'foreign'})
    rejected('wrong_protected_source',namespace['protected'],'wrong-source')
    write(protected,report)
    write(root/'receipt-protected/original/protected-matrix/retained_selected/summary.json',dict(run_completed=True,correctness_passed=True,source_git_commit=sha,gates=[dict(required=True,passed=i!=245) for i in range(246)]))
    rejected('false_raw_protected_gate_despite_pass_badge',namespace['protected'],'raw protected gate mismatch/failure')
    write(root/'receipt-comparison/summary.json',dict(schema='mathgraph.retained-receipt-index-comparison.v1',source_sha='foreign'))
    rejected('wrong_comparison_source',namespace['comparison'],'wrong comparison schema/source')
    write(root/'receipt-comparison/summary.json',dict(schema='mathgraph.retained-receipt-index-comparison.v1',source_sha=sha,completed=False,qualified=True,correctness_passed=True))
    rejected('incomplete_comparison_despite_pass_flags',namespace['comparison'],'incomplete comparison')
    write(root/'original-qualification/summary.json',dict(qualification_passed=True,source_git_commit=sha,gates=[dict(passed=i!=196) for i in range(197)]))
    rejected('false_legacy_gate_despite_pass_flag',lambda:namespace['legacy']('original-qualification','qualification_passed',197,True),'missing/failed required gates')
report={'schema':'mathgraph.receipt-publisher-synthetic-refusal-tests.v1','passed':True,'test_count':len(results),'tests':results}
out=repo.parent/'kernel-audit/retained-admission-continuation/receipt-publisher-falsifiers.json'
out.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
