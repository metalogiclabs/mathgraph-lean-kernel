#!/usr/bin/env python3
"""Diagnostic operation timing on the actual admitted retained-kernel path."""
import sys,json,time,hashlib,cProfile,pstats,io,subprocess
from pathlib import Path
sys.path.insert(0,'/workspace/mathgraph-lean-kernel-retained-admission/experiments/incremental')
import producer_delta as p
import qualify_delta as q
out=Path('/workspace/kernel-audit/retained-admission-continuation/profile-expanded-early-after')
out.mkdir(parents=True,exist_ok=False)
bins=Path('/workspace/mathgraph-lean-kernel/target/release')
work=Path('/workspace/kernel-audit/delta-expanded-workloads-first')
s=p.DeltaSession(root=out/'session',workloads=work,
 producer=Path('/workspace/kernel-audit/delta-qualified-tools/delta-producer'),
 checker=bins/'check-selected',indexer=bins/'export-index',index_session=bins/'index-session',
 authority_key=Path('/workspace/kernel-audit/retained-admission-continuation-authority/issuer.key'),
 sparse_index_wire=True,sparse_receipt=True,frozen_baseline=True,
 retained_checker=bins/'check-selected-retained-session')
ops=[];active=False
original_encoded=p.engine.encoded

def encoded(value):
 if not active:return original_encoded(value)
 t=time.perf_counter();c=time.process_time();raw=original_encoded(value)
 if type(value) is dict and type(value.get('declarations')) is list:
  ops.append(dict(operation='canonical_encode_full_index',count=value.get('count'),
   bytes=len(raw),wall_seconds=time.perf_counter()-t,cpu_seconds=time.process_time()-c))
 return raw
p.engine.encoded=encoded

def wrap(owner,name):
 old=getattr(owner,name)
 def call(*a,**k):
  if not active:return old(*a,**k)
  t=time.perf_counter();c=time.process_time()
  try:return old(*a,**k)
  finally:ops.append(dict(operation=name,wall_seconds=time.perf_counter()-t,cpu_seconds=time.process_time()-c))
 setattr(owner,name,call)
for owner,name in [(p,'authenticate_sparse_acceptance'),(p,'reconstruct_index_patch'),(p.engine,'reuse_decisions')]:wrap(owner,name)
profile=cProfile.Profile()
try:
 setup=s.start()
 transaction=s.prepare(work/'early-definition/source',q.EDITS['early-definition'],q.NAMES['early-definition'])
 active=True;profile.enable();tick=time.perf_counter()
 result=s.validate_apply(transaction)
 elapsed=time.perf_counter()-tick;profile.disable();active=False
 assert result['status']=='VERIFIED' and result['counts']['rechecked']==672
 (out/'result.json').write_text(json.dumps(result,sort_keys=True)+'\n')
 fullconfig=out/'full-config.json';fullconfig.write_bytes(q.canonical(q.configuration(s.snapshot_path)))
 oracles=[]
 for name,cmd in [
  ('full-rust',[str(bins/'sokonanoda'),str(fullconfig)]),
  ('leanchecker',['/home/agent/.elan/toolchains/leanprover--lean4---v4.35.0/bin/leanchecker','--silent','--from-export',s.snapshot_path]),
  ('leanchecker-paranoid',['/home/agent/.elan/toolchains/leanprover--lean4---v4.35.0/bin/leanchecker-paranoid','--silent','--from-export',s.snapshot_path])]:
  run=subprocess.run(cmd,capture_output=True,timeout=120)
  (out/(name+'.stdout')).write_bytes(run.stdout);(out/(name+'.stderr')).write_bytes(run.stderr)
  assert run.returncode==0,(name,run.returncode)
  oracles.append(dict(name=name,returncode=run.returncode))
 stream=io.StringIO();pstats.Stats(profile,stream=stream).strip_dirs().sort_stats('cumulative').print_stats(45)
 (out/'cprofile.txt').write_text(stream.getvalue());profile.dump_stats(out/'cprofile.pstats')
 report=dict(schema='mathgraph.retained-receipt.operation-profile.v1',scope='Instrumented diagnostic, not benchmark; nested operation timings overlap. Actual authenticated source-owned retained kernel and fresh full Rust/C++/paranoid.',
 source_git_head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(), source_status=subprocess.check_output(['git','status','--porcelain'],text=True), adapter_sha256=hashlib.sha256(Path(p.__file__).read_bytes()).hexdigest(), setup=setup,operations=ops,
 validate_apply_wall_seconds=elapsed,timings=result['timings'],counts=result['counts'],
 full_oracles=oracles,export_sha256=result['export_sha256'])
 (out/'summary.json').write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps({k:report[k] for k in ['scope','validate_apply_wall_seconds','operations','counts','full_oracles']},indent=2))
finally:s.close()
