#!/usr/bin/env python3
"""Independent report/source arithmetic audit; no runtime/controller imports."""
import copy, hashlib, json, math, random, statistics, subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parent
REPO=Path('/workspace/mathgraph-lean-kernel')
SOURCE='6e717043b85acdad63c2399131cb5f9a7432ee37'
VARIANTS=('early-definition','unrelated-definition')
N={'original':3436,'expanded':11653}
COUNTS={'original':{'early-definition':413,'unrelated-definition':1,'theorem-leaf':1,'baseline':0},'expanded':{'early-definition':672,'unrelated-definition':260,'theorem-leaf':260,'baseline':0}}
SHA=lambda raw:hashlib.sha256(raw).hexdigest()

def load(path):return json.loads(Path(path).read_bytes())
def canonical(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False).encode()
class Checks:
 def __init__(self):self.count=0
 def need(self,name,condition):
  self.count+=1
  if not condition:raise ValueError(name)
 def eq(self,name,a,b):self.need(name,canonical(a)==canonical(b))
 def near(self,name,a,b):self.need(name,type(a) in (int,float) and math.isfinite(a) and math.isclose(a,b,abs_tol=1e-12,rel_tol=1e-12))
 def num(self,name,a):self.need(name,type(a) in (int,float) and math.isfinite(a) and a>=0)

def economics(num,den,seed):
 med=statistics.median;ratio=med(num)/med(den);rng=random.Random(seed);draws=[]
 for _ in range(10000):
  ids=[rng.randrange(len(num)) for _ in num];draws.append(med([num[i] for i in ids])/med([den[i] for i in ids]))
 draws.sort();bounds=[draws[249],draws[9749]];wins=sum(a<b for a,b in zip(num,den));passed=ratio<1 and 2*wins>len(num) and bounds[1]<1
 return dict(apply_median_wall_seconds=med(num),direct_median_wall_seconds=med(den),median_ratio=ratio,paired_wins=wins,paired_count=len(num),bootstrap_ratio_interval_95=bounds,bootstrap_repetitions=10000,bootstrap_seed=seed,passed=passed,status='SPEEDUP' if passed else 'NO_SPEEDUP')

def check_economics(c,name,reported,num,den,seed):
 out=economics(num,den,seed)
 for k,v in out.items():
  if type(v) is float:c.near(name+':'+k,reported[k],v)
  else:c.eq(name+':'+k,reported[k],v)
 return out

def ab_review(report,c):
 c.eq('AB:schema',report['schema'],'mathgraph.retained-kernel-issuer-accepted-ab.v1');c.eq('AB:source',report['source_sha'],SOURCE)
 c.need('AB:completed',report.get('completed') is True and report.get('qualified') is True)
 c.eq('AB:profiles',sorted(report['profiles']),['expanded','original']);result={}
 for p,profile in report['profiles'].items():
  c.need(p+':cold',profile['cold_restart'].get('passed') is True)
  result[p]={}
  for variant in VARIANTS:
   r=profile[variant];c.need(p+variant+':complete',r['complete'] is True and len(r['pairs'])==5)
   c.eq(p+variant+':unique-reps',sorted(x['repetition'] for x in r['pairs']),list(range(5)))
   for pair in r['pairs']:
    i=pair['repetition'];c.eq('AB:variant',pair['variant'],variant)
    expected=['fresh_selected','retained_selected'] if (i+(variant=='unrelated-definition'))%2==0 else ['retained_selected','fresh_selected']
    c.eq('AB:alternating-order',pair['order'],expected);c.eq('AB:both-arms',sorted(pair['arms']),['fresh_selected','retained_selected'])
    for arm,a in pair['arms'].items():
     for f in ('wall_seconds','kernel_seconds','identity_seconds','producer_seconds','persistence_seconds','setup_seconds'):c.num('AB:duration:'+f,a[f])
     c.eq('AB:actual-checked',a['checked'],COUNTS[p][variant]);c.eq('AB:actual-reuse',a['reused'],N[p]-a['checked'])
     if arm=='retained_selected':
      k=a['kernel_report'];c.eq('AB:actual-kernel',k['kernel'],'sokonanoda_real_selected_declaration_check');c.eq('AB:kernel-status',k['status'],'checked');c.eq('AB:kernel-code',k['code'],0)
      c.eq('AB:kernel-checked',k['checked'],a['checked']);c.eq('AB:kernel-total',k['total_declarations'],N[p]);c.eq('AB:kernel-scope',k['scope'],'selected_obligations_under_caller_trusted_environment')
     else:c.eq('AB:fresh-no-retained-report',a['kernel_report'],None)
     if i==0:c.eq('AB:official-independent-oracles',a['cpp_oracles'],{'leanchecker':0,'leanchecker-paranoid':0})
    for f in ('checked','reused','export_sha256','decisions_sha256'):c.eq('AB:arm-parity:'+f,pair['arms']['fresh_selected'][f],pair['arms']['retained_selected'][f])
   out={}
   for phase,field,seed in [('warm_economics','wall_seconds',20261017),('selected_kernel_economics','kernel_seconds',20261027)]:
    num=[x['arms']['retained_selected'][field] for x in r['pairs']];den=[x['arms']['fresh_selected'][field] for x in r['pairs']]
    out[phase]=check_economics(c,p+variant+phase,r[phase],num,den,seed)
    out[phase]['actual_comparator_scope']='complete retained-selected accepted warm pipeline / complete fresh-selected accepted warm pipeline' if field=='wall_seconds' else 'retained genuine selected-check phase / fresh process selected-check phase'
    out[phase]['reported_scope_is_inherited_mislabel']=r[phase].get('scope')=='warm authenticated session update versus fresh full Rust command'
   out['phase_medians']={arm:{f:statistics.median(x['arms'][arm][f] for x in r['pairs']) for f in ('wall_seconds','kernel_seconds','identity_seconds','producer_seconds','persistence_seconds','setup_seconds')} for arm in ('fresh_selected','retained_selected')}
   for arm in ('fresh_selected','retained_selected'):c.near('AB:startup-median',r['median_startup_s'][arm],out['phase_medians'][arm]['setup_seconds'])
   result[p][variant]=out
 return result

def protected_review(report,c,profile):
 c.eq('protected:source',report['source_git_commit'],SOURCE);c.eq('protected:schema',report['schema'],'mathgraph.authenticated-producer-delta-qualification.v1')
 c.need('protected:complete',all(report.get(f) is True for f in ('run_completed','correctness_passed')) and report['qualification_status']=='PASS')
 gates=report['gates'];c.eq('protected:exact-gate-count',len(gates),246 if profile=='original' else 229)
 c.need('protected:all-gates',all(g['passed'] is True for g in gates if g['required']));c.need('protected:unique-gates',len(gates)==len({g['name'] for g in gates}))
 samples=report['samples'];c.eq('protected:samples',len(samples),21)
 ids=[(s['variant'],s['repetition']) for s in samples if not s['cold_replay']]
 c.need('protected:five-each',len(ids)==20 and len(set(ids))==20 and set(ids)=={(v,i) for v in ('early-definition','unrelated-definition','theorem-leaf','baseline') for i in range(5)})
 c.eq('protected:one-cold',sum(s['cold_replay'] for s in samples),1)
 for s in samples:
  a=s['partition_audit'];n=N[profile];count=COUNTS[profile][s['variant']]
  c.eq('protected:real-check-count',a['actual_kernel_checked'],count);c.eq('protected:real-total',a['actual_kernel_total'],n)
  c.eq('protected:real-reuse',a['independently_replayed_reused'],n-count)
  checked,reused=a['checked_indices'],a['reused_indices'];c.need('protected:partition',len(set(checked))==len(checked)==count and len(set(reused))==len(reused)==n-count and not set(checked)&set(reused) and set(checked+reused)==set(range(n)))
  c.eq('protected:raw-success',s['direct_rust']['returncode'],0);c.eq('protected:raw-no-timeout',s['direct_rust']['timed_out'],False)
  p=s['setup_report']['delta_provenance'];c.eq('protected:actual-native-policy',p['selected_kernel_backend'],'sha-pinned-retained-parser-v1')
  c.eq('protected:actual-native-tool',p['tools']['retained_checker'],report['tools']['retained_checker']['sha256'])
  c.eq('protected:live-source',p['adapter_sha256'],report['measured_source_sha256']['experiments/incremental/producer_delta.py'])
  r=s['persisted_acceptance_audit'];c.need('protected:issuer-audit',r['issuer_hmac_valid'] is True and r['all_content_addresses_valid'] is True)
  full_fallback=s['variant']=='theorem-leaf'
  c.eq('protected:receipt-schema',r['receipt_schema'],'mathgraph.incremental-lean.v1' if full_fallback else 'mathgraph.incremental-lean.sparse-accepted.v1');c.eq('protected:full-index-only-fallback',r['contains_complete_index'],full_fallback)
  if s['repetition']==0:
   c.eq('protected:Cpp-oracle-set',sorted(s['independent_kernels']),['leanchecker','leanchecker-paranoid'])
   for command in s['independent_kernels'].values():c.eq('protected:Cpp-verdict',command['returncode'],0)
 result={}
 for variant in ('early-definition','unrelated-definition','theorem-leaf','baseline'):
  rows=[s for s in samples if s['variant']==variant and not s['cold_replay']]
  result[variant]=check_economics(c,'protected:raw:'+variant,report['economics'][variant],[s['apply_wall_seconds'] for s in rows],[s['direct_wall_seconds'] for s in rows],20261016)
 causes={'forged-attestation':'issuer authentication failed','authenticated-attestation-version-drift':'wrong authority domain',
  'authenticated-baseline-environment-drift':'transition environment/version/base mismatch','authenticated-base-export-drift':'transition environment/version/base mismatch','authenticated-producer-version-drift':'transition environment/version/base mismatch',
  'unannounced-source-change':'source modifications outside the reported patch','outside-announced-region':'source modifications outside the reported patch','import-environment-drift':'source modifications outside the reported patch','false-announced-name':'expected_changed_names differs from complete local comparison',
  'corrupt-baseline-receipt':'evidence content address mismatch','corrupt-baseline-export':'baseline storage corruption','corrupt-genesis':'delta storage corruption: genesis','corrupt-accepted-delta-receipt':'delta storage corruption: records','corrupt-persisted-delta-bytes':'delta storage corruption: deltas','corrupt-persisted-transition':'delta storage corruption: transitions','corrupt-persisted-representation':'delta storage corruption: representations','foreign-issuer-authority':'evidence issuer authentication failed'}
 c.eq('protected:21-controls',len(report['controls']),21)
 c.eq('protected:complete-control-names',sorted(report['controls']),sorted(set(causes)|{'signed-invalid-proof','signed-invalid-axiom','unused-invalid-node-zero-selection-parser','unused-invalid-node-dag-only-zero-selection-parser'}))
 for name,control in report['controls'].items():
  if name in causes:
   observed=control.get('exception_refusal',control.get('observed_refusal',control.get('result',{}).get('reason','')))
   c.need('control:intended-cause:'+name,causes[name] in observed)
  if 'result' in control:
   r=control['result'];c.need('control:no-acceptance',r.get('evidence_id') is None and r.get('receipt_id') is None and r.get('status') in ('UNKNOWN','REJECTED'))
  if name.startswith(('signed-invalid','unused-invalid')):
   r=control['result'];c.eq('control:actual-reject',r['status'],'REJECTED');c.eq('control:reject-code',r['checker_result']['code'],1)
   c.eq('control:three-independent-oracles',sorted(control['independent_kernel_rejections']),['leanchecker','leanchecker-paranoid','rust'])
   for cmd in control['independent_kernel_rejections'].values():c.need('control:full-reject',type(cmd['returncode']) is int and cmd['returncode']==1 and cmd['timed_out'] is False)
   if name.startswith('unused-invalid'):c.eq('control:zero-selected',r['counts']['scheduled'],0);c.need('control:independent-zero-parser',control['independent_zero_selected_parser']['returncode']!=0)
  elif 'exception_refusal' in control:c.need('control:not-timeout','timeout' not in control['exception_refusal'].lower())
  elif 'observed_refusal' in control:c.need('control:not-timeout','timeout' not in control['observed_refusal'].lower())
 return result

def main():
 c=Checks();artifact=ROOT/'artifact';ab=load(artifact/'retained-admission-ab/summary.json');aggregate=load(artifact/'retained-admission-protected/protected-summary.json')
 c.eq('aggregate:source',aggregate['source_sha'],SOURCE);c.need('aggregate:qualified',aggregate['qualified'] is True)
 results={'source':SOURCE,'run':38995206988,'scope':'independent compact report/source/arithmetic audit, no new kernel run or historical HMAC authentication','ab':ab_review(ab,c),'protected':{},'source_bindings':{}}
 for profile in ('original','expanded'):
  r=load(artifact/f'retained-admission-protected/{profile}/protected-matrix/retained_selected/summary.json');results['protected'][profile]=protected_review(r,c,profile)
  for field in ('source_sha','qualification_status'):c.eq('aggregate:bind:'+field,aggregate['profiles'][profile][field],SOURCE if field=='source_sha' else 'PASS')
  c.eq('aggregate:gate-count',aggregate['profiles'][profile]['required_gates'],sum(g['required'] for g in r['gates']))
  for path,digest in r['measured_source_sha256'].items():
   actual=SHA(subprocess.check_output(['git','show',SOURCE+':'+path],cwd=REPO));c.eq('source:Git:'+path,digest,actual);results['source_bindings'][path]=actual
  c.eq('source:harness',r['harness_sha256'],results['source_bindings']['experiments/incremental/qualify_delta.py'])
  for field,tool in [('producer','producer'),('checker','checker'),('retained_checker','retained_checker'),('indexer','indexer'),('index_session','index_session'),('full_checker','full_checker')]:c.eq('binary:AB-protected:'+field,ab['binary_sha256'][field],r['tools'][tool]['sha256'])
  c.eq('binary:aggregate',aggregate['profiles'][profile]['retained_kernel_tool_sha256'],r['tools']['retained_checker']['sha256'])
 for path,digest in ab['source_sha256'].items():c.eq('AB:source:Git:'+path,digest,SHA(subprocess.check_output(['git','show',SOURCE+':'+path],cwd=REPO)))
 falsifiers=[]
 for name,mutate in [('partial',lambda r:r.update(completed=False)),('missing-pair',lambda r:r['profiles']['original']['early-definition']['pairs'].pop()),('wrong-source',lambda r:r.update(source_sha='0'*40)),('altered-timing',lambda r:r['profiles']['original']['early-definition']['pairs'][0]['arms']['retained_selected'].update(wall_seconds=99)),('forged-checked-count',lambda r:r['profiles']['expanded']['early-definition']['pairs'][0]['arms']['retained_selected'].update(checked=0)),('wrong-kernel',lambda r:r['profiles']['expanded']['early-definition']['pairs'][0]['arms']['retained_selected']['kernel_report'].update(kernel='hint_only')),('false-cold',lambda r:r['profiles']['original']['cold_restart'].update(passed=False))]:
  value=copy.deepcopy(ab);mutate(value)
  try:ab_review(value,Checks())
  except (ValueError,KeyError,TypeError,IndexError) as e:falsifiers.append(dict(name=name,passed=True,refusal=str(e)))
  else:raise ValueError('falsifier unexpectedly accepted:'+name)
 results.update(status='PASS_REPORT_ARITHMETIC_WITH_SCOPE_CORRECTIONS_AND_LIMITS',passed=True,check_count=c.count,falsifiers=falsifiers,
  scope_corrections=['AB denominator is fresh-selected complete authenticated pipeline, not raw full Rust despite inherited scope string.','selected_kernel_economics measures only checking subphase despite inherited whole-update scope string.'],
  limitations=['Historical issuer keys/caches/receipt objects/native result responses and raw outputs are absent; no old HMAC authentication or kernel execution was performed.','Artifact excludes AB inner qualifier summaries and result.json files.','Sparse signed acceptance and frozen admitted baseline are already qualified ancestors; new trusted dependency is the one-shot parser/kernel bridge.','No complete warm improvement is qualified for either primary early edit; unrelated expanded is a negative.','No CPU/memory/per-phase waiting attribution or full lifecycle economics was archived for the A/B projection.','Full composite materialization/hash and whole-index receipt reconstruction/canonical comparison remain O(N).'])
 (ROOT/'report-review.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps({k:results[k] for k in ('status','passed','check_count')}))
if __name__=='__main__':main()
