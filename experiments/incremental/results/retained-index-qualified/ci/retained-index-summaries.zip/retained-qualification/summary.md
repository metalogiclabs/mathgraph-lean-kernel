Retained index qualification: PASS

Two pinned environments; early cone3 and unrelated cone1. Five paired repetitions required.
Reclosure compute, whole finish, complete JSON roundtrip, warm adapter, and one-update lifecycle are separate measurements.
Shutdown uses the supported SIGTERM/wait API. No multi-update amortization or aggregate memory claim.

Forced-full wholefinish includes observation-only counters; its core compute is the untouched historical algorithm. The preserved449 adapter is the primary historical comparator.

| Profile / edit | Warm vs449 ratio | Warm vs full ratio | One-update API sum vs449 ratio |
| --- | ---: | ---: | ---: |
| original / early-definition | 0.9023 | 0.8876 | 0.9975 |
| original / unrelated-definition | 0.8617 | 0.8407 | 0.9929 |
| expanded / early-definition | 0.8899 | 0.8601 | 0.9961 |
| expanded / unrelated-definition | 0.8828 | 0.8533 | 0.9918 |
