# Native identity-index whole-process benchmark

**Correctness:** PASS. **Economic result:** NO_SPEEDUP.

Median fresh-process measurements; seconds and KiB. Raw logs and all repetitions are retained in `summary.json` and per-command files.

| Variant | Arm | Wall | CPU | Peak RSS |
| --- | --- | ---: | ---: | ---: |
| baseline | baseline-python-full | 5.862746 | 5.853380 | 289188 |
| baseline | baseline-python-incremental | 0.192084 | 0.183439 | 275352 |
| baseline | native-full | 0.645552 | 0.634428 | 275352 |
| baseline | native-incremental | 0.191931 | 0.187597 | 275352 |
| baseline | baseline-direct-full | 0.273099 | 0.270911 | 275352 |
| baseline | current-direct-full | 0.273752 | 0.272173 | 275352 |
| early-definition | baseline-python-full | 5.852366 | 5.845660 | 284056 |
| early-definition | baseline-python-incremental | 5.671366 | 5.662537 | 295772 |
| early-definition | native-full | 0.656278 | 0.642525 | 275352 |
| early-definition | native-incremental | 0.464363 | 0.455053 | 275352 |
| early-definition | baseline-direct-full | 0.272959 | 0.269458 | 275352 |
| early-definition | current-direct-full | 0.272829 | 0.271092 | 275352 |
| unrelated-definition | baseline-python-full | 5.842879 | 5.827954 | 288108 |
| unrelated-definition | baseline-python-incremental | 5.651868 | 5.637392 | 295856 |
| unrelated-definition | native-full | 0.646098 | 0.637477 | 275352 |
| unrelated-definition | native-incremental | 0.434381 | 0.424174 | 275352 |
| unrelated-definition | baseline-direct-full | 0.282659 | 0.274522 | 275352 |
| unrelated-definition | current-direct-full | 0.282772 | 0.278660 | 275352 |
| theorem-leaf | baseline-python-full | 5.884378 | 5.873204 | 288168 |
| theorem-leaf | baseline-python-incremental | 5.626088 | 5.615522 | 297068 |
| theorem-leaf | native-full | 0.645844 | 0.637691 | 275352 |
| theorem-leaf | native-incremental | 0.434009 | 0.423044 | 275352 |
| theorem-leaf | baseline-direct-full | 0.272959 | 0.272479 | 275352 |
| theorem-leaf | current-direct-full | 0.272754 | 0.270695 | 275352 |
| invalid-proof | baseline-python-full | 5.792613 | 5.784168 | 279252 |
| invalid-proof | baseline-python-incremental | 5.640904 | 5.635733 | 288024 |
| invalid-proof | native-full | 0.596025 | 0.595251 | 275352 |
| invalid-proof | native-incremental | 0.383763 | 0.380086 | 275352 |
| invalid-proof | baseline-direct-full | 0.283056 | 0.276493 | 275352 |
| invalid-proof | current-direct-full | 0.282835 | 0.273793 | 275352 |
| axiom-type | baseline-python-full | 5.555645 | 5.552479 | 279248 |
| axiom-type | baseline-python-incremental | 5.650384 | 5.648095 | 288056 |
| axiom-type | native-full | 0.353176 | 0.345520 | 275352 |
| axiom-type | native-incremental | 0.403836 | 0.401279 | 275352 |
| axiom-type | baseline-direct-full | 0.031378 | 0.029243 | 275352 |
| axiom-type | current-direct-full | 0.030804 | 0.029551 | 275352 |

| Primary variant | Native/direct median ratio | Paired wins | Bootstrap 95% interval | Economic gate |
| --- | ---: | ---: | --- | --- |
| early-definition | 1.7020 | 0/5 | [1.6404, 1.7385] | NO_SPEEDUP |
| unrelated-definition | 1.5362 | 0/5 | [1.5339, 1.6281] | NO_SPEEDUP |

The prespecified rule requires a lower median, a strict majority of paired wins and a paired-bootstrap 95% upper ratio bound below one for both primary edits. The comparison uses current direct raw full checking.

Baseline seeding is separate from timed incremental verification. Build/export resources and component-addition totals are reported separately; those sums are not new single-command measurements. Bootstrap stability on this finite run does not establish cross-host or Mathlib-scale speedup.

`max_rss_kib` is the raw wait4 highwater. It can include memory inherited from this Python launcher before exec, so it does not establish checker-only or aggregate process-tree peak memory or memory savings. The separate `profile_native_phases.py` diagnostic records post-exec RSS samples by phase.

Failed correctness gates: 
