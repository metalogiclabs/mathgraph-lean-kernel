# Incremental external checking qualification

Qualification passed: **True**

| Edit | Full obligations | Rechecked | Reused | Fresh verify s | Incremental verify s | Fresh build+export+verify s | Incremental build+export+verify s |
|---|---:|---:|---:|---:|---:|---:|---:|
| no-change | 3436 | 0 | 3436 | 0.647 | 0.192 | 2.908 | 2.453 |
| early-definition | 3436 | 413 | 3023 | 0.656 | 0.455 | 2.676 | 2.476 |
| unrelated-definition | 3436 | 1 | 3435 | 0.646 | 0.424 | 2.687 | 2.466 |
| theorem-leaf | 3436 | 1 | 3435 | 0.636 | 0.434 | 2.677 | 2.475 |
| type-change | 3436 | 2 | 3434 | 0.636 | 0.424 | 2.680 | 2.468 |
| invalid-proof | 3436 | None | 3435 | 0.596 | 0.383 | boundary mutation | boundary mutation |
| axiom-type | 3436 | None | 0 | 0.353 | 0.404 | boundary mutation | boundary mutation |
| toolchain-metadata | 3436 | 3436 | 0 | 0.636 | 0.686 | boundary mutation | boundary mutation |
| malformed-unused-dag | ? | ? | ? | 5.730 | 5.781 | boundary mutation | boundary mutation |
| malformed-unused-typed-node | 3436 | None | 3436 | 5.721 | 5.753 | boundary mutation | boundary mutation |

Authenticated selected-obligation work reduction and exact-export oracle agreement. Timing medians are observations; edit speedup is not assumed. The bounded Lean theorem does not verify the NDJSON dependency extractor or production kernel locality.

Optional kernel statuses: lean4lean=ACCEPT, con-leche=ACCEPT, con-ron=ACCEPT, nanoda_bin=ACCEPT

Failed gates: 
