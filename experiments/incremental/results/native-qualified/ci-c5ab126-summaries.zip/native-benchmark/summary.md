# Native identity-index whole-process benchmark

**Correctness:** PASS. **Economic result:** NO_SPEEDUP.

Median fresh-process measurements; seconds and KiB. Raw logs and all repetitions are retained in `summary.json` and per-command files.

| Variant | Arm | Wall | CPU | Peak RSS |
| --- | --- | ---: | ---: | ---: |
| baseline | baseline-python-full | 4.320825 | 4.221900 | 287308 |
| baseline | baseline-python-incremental | 0.181889 | 0.152110 | 274720 |
| baseline | native-full | 0.636173 | 0.527968 | 274720 |
| baseline | native-incremental | 0.181911 | 0.155219 | 274720 |
| baseline | baseline-direct-full | 0.232544 | 0.223001 | 274720 |
| baseline | current-direct-full | 0.222530 | 0.221906 | 274720 |
| early-definition | baseline-python-full | 4.339893 | 4.235834 | 284052 |
| early-definition | baseline-python-incremental | 4.179580 | 4.071494 | 293424 |
| early-definition | native-full | 0.635886 | 0.524923 | 274720 |
| early-definition | native-incremental | 0.474243 | 0.369741 | 274720 |
| early-definition | baseline-direct-full | 0.232633 | 0.229902 | 274720 |
| early-definition | current-direct-full | 0.232772 | 0.225714 | 274720 |
| unrelated-definition | baseline-python-full | 4.331822 | 4.230306 | 287244 |
| unrelated-definition | baseline-python-incremental | 4.158966 | 4.052825 | 293960 |
| unrelated-definition | native-full | 0.626173 | 0.522709 | 274720 |
| unrelated-definition | native-incremental | 0.454681 | 0.351083 | 274720 |
| unrelated-definition | baseline-direct-full | 0.232826 | 0.223510 | 274720 |
| unrelated-definition | current-direct-full | 0.232642 | 0.226668 | 274720 |
| theorem-leaf | baseline-python-full | 4.348201 | 4.244833 | 287328 |
| theorem-leaf | baseline-python-incremental | 4.159231 | 4.063200 | 297172 |
| theorem-leaf | native-full | 0.615752 | 0.521393 | 274720 |
| theorem-leaf | native-incremental | 0.454159 | 0.346210 | 274720 |
| theorem-leaf | baseline-direct-full | 0.232579 | 0.227166 | 274720 |
| theorem-leaf | current-direct-full | 0.232608 | 0.222487 | 274720 |
| invalid-proof | baseline-python-full | 4.199176 | 4.195871 | 279320 |
| invalid-proof | baseline-python-incremental | 4.017905 | 4.016120 | 288100 |
| invalid-proof | native-full | 0.504923 | 0.501977 | 274720 |
| invalid-proof | native-incremental | 0.312999 | 0.310115 | 274720 |
| invalid-proof | baseline-direct-full | 0.232591 | 0.225910 | 274720 |
| invalid-proof | current-direct-full | 0.232625 | 0.225245 | 274720 |
| axiom-type | baseline-python-full | 4.036073 | 4.035664 | 279320 |
| axiom-type | baseline-python-incremental | 4.069818 | 4.059170 | 288088 |
| axiom-type | native-full | 0.292858 | 0.284291 | 274720 |
| axiom-type | native-incremental | 0.333285 | 0.329454 | 274720 |
| axiom-type | baseline-direct-full | 0.030712 | 0.023356 | 274720 |
| axiom-type | current-direct-full | 0.030727 | 0.024474 | 274720 |

| Primary variant | Native/direct median ratio | Paired wins | Bootstrap 95% interval | Economic gate |
| --- | ---: | ---: | --- | --- |
| early-definition | 2.0374 | 0/5 | [1.8339, 2.1328] | NO_SPEEDUP |
| unrelated-definition | 1.9544 | 0/5 | [1.9084, 1.9998] | NO_SPEEDUP |

The prespecified rule requires a lower median, a strict majority of paired wins and a paired-bootstrap 95% upper ratio bound below one for both primary edits. The comparison uses current direct raw full checking.

Baseline seeding is separate from timed incremental verification. Build/export resources and component-addition totals are reported separately; those sums are not new single-command measurements. Bootstrap stability on this finite run does not establish cross-host or Mathlib-scale speedup.

`max_rss_kib` is the raw wait4 highwater. It can include memory inherited from this Python launcher before exec, so it does not establish checker-only or aggregate process-tree peak memory or memory savings. The separate `profile_native_phases.py` diagnostic records post-exec RSS samples by phase.

Failed correctness gates: 
