# Incremental external checking qualification

Qualification passed: **True**

| Edit | Full obligations | Rechecked | Reused | Fresh verify s | Incremental verify s | Fresh build+export+verify s | Incremental build+export+verify s |
|---|---:|---:|---:|---:|---:|---:|---:|
| no-change | 3436 | 0 | 3436 | 0.626 | 0.162 | 2.470 | 2.006 |
| early-definition | 3436 | 413 | 3023 | 0.616 | 0.364 | 2.343 | 2.091 |
| unrelated-definition | 3436 | 1 | 3435 | 0.615 | 0.343 | 2.345 | 2.072 |
| theorem-leaf | 3436 | 1 | 3435 | 0.616 | 0.344 | 2.334 | 2.062 |
| type-change | 3436 | 2 | 3434 | 0.616 | 0.343 | 2.343 | 2.071 |
| invalid-proof | 3436 | None | 3435 | 0.495 | 0.313 | boundary mutation | boundary mutation |
| axiom-type | 3436 | None | 0 | 0.283 | 0.333 | boundary mutation | boundary mutation |
| toolchain-metadata | 3436 | 3436 | 0 | 0.616 | 0.565 | boundary mutation | boundary mutation |
| malformed-unused-dag | ? | ? | ? | 4.137 | 4.189 | boundary mutation | boundary mutation |
| malformed-unused-typed-node | 3436 | None | 3436 | 4.086 | 4.138 | boundary mutation | boundary mutation |

Authenticated selected-obligation work reduction and exact-export oracle agreement. Timing medians are observations; edit speedup is not assumed. The bounded Lean theorem does not verify the NDJSON dependency extractor or production kernel locality.

Optional kernel statuses: lean4lean=ACCEPT, con-leche=ACCEPT, con-ron=ACCEPT, nanoda_bin=ACCEPT

Failed gates: 
